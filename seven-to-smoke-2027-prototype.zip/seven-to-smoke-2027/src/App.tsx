import { useState, type FormEvent } from "react";
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, Award, BarChart3, Check,
  ChevronDown, CirclePlay, Clock3, Instagram, Mail, Menu, Radio,
  ShieldCheck, Smartphone, Sparkles, Trophy, Users, Video, X, Zap
} from "lucide-react";

const nav = [
  ["Le championnat", "#championship"],
  ["L'expérience", "#experience"],
  ["Partenaires", "#partners"],
  ["Organisateurs", "#organizers"],
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", company: "", email: "", interest: "Partenariat stratégique", message: "" });

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Demande de partenariat — ${form.company}`);
    const body = encodeURIComponent(
      `Nom : ${form.name}\nOrganisation : ${form.company}\nEmail : ${form.email}\nIntérêt : ${form.interest}\n\n${form.message}`
    );
    window.location.href = `mailto:partenariats@seven-to-smoke.com?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <div className="site-shell">
      <div className="topline">
        <span><span className="live-dot" /> ÉDITION 2027 · KINSHASA, RDC</span>
        <span className="topline-right">UNE SCÈNE. 20 TALENTS. 7 FINALISTES.</span>
      </div>

      <header className="header">
        <a className="brand" href="#home" aria-label="Seven to Smoke accueil">
          <span className="brand-mark">7</span>
          <span className="brand-copy"><strong>SEVEN<span>TO</span>SMOKE</strong><small>AFRICAN URBAN DANCE CHAMPIONSHIP</small></span>
        </a>
        <nav className={menuOpen ? "nav nav-open" : "nav"}>
          {nav.map(([label, href]) => <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
          <a className="nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>Devenir partenaire <ArrowUpRight size={15}/></a>
        </nav>
        <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Ouvrir le menu">
          {menuOpen ? <X/> : <Menu/>}
        </button>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-image" />
          <div className="hero-grain" />
          <div className="hero-content wrap">
            <div className="eyebrow"><span className="eyebrow-line"/> THE NEXT GENERATION OF AFRICAN STREET DANCE</div>
            <h1>THE FLOOR<br/><em>IS YOURS.</em></h1>
            <p className="hero-lead">Le talent. La discipline.<br/><strong>La performance.</strong></p>
            <p className="hero-desc">Une nouvelle scène pour révéler les talents de la danse urbaine africaine. Une compétition où chaque mouvement compte et où les sept dernières places se méritent.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#championship">Découvrir le championnat <ArrowUpRight size={17}/></a>
              <a className="button button-ghost" href="#partners">Opportunités partenaires <ArrowDownRight size={17}/></a>
            </div>
            <div className="hero-footnote"><span>01 / 07</span><span className="hero-footnote-line"/><span>BUILT FOR CULTURE. DESIGNED FOR IMPACT.</span></div>
          </div>
          <div className="hero-stamp"><span>AFRICAN</span><strong>URBAN<br/>CULTURE</strong><span>CHAMPIONSHIP · 2027</span></div>
        </section>

        <section className="numbers-strip">
          <div className="wrap numbers-grid">
            <div><strong>20</strong><span>DANSEURS SÉLECTIONNÉS</span></div>
            <div><strong>05<span>′</span></strong><span>CHORÉGRAPHIE IMPOSÉE</span></div>
            <div><strong>07</strong><span>FINALISTES</span></div>
            <div><strong>3,5M</strong><span>FC DE CAGNOTTE PRÉVUE</span></div>
          </div>
        </section>

        <section className="section intro-section wrap" id="championship">
          <div className="section-kicker">01 — THE CHAMPIONSHIP</div>
          <div className="intro-grid">
            <div>
              <h2>PLUS QU'UN<br/><em>CHALLENGE.</em></h2>
              <p className="intro-big">Une plateforme d'expression, de dépassement et de reconnaissance pour la culture urbaine africaine.</p>
            </div>
            <div className="intro-copy">
              <p>SEVEN TO SMOKE réunit vingt danseurs autour d'une création chorégraphique commune. Après une période de répétitions et d'évaluation, les participants avancent à travers des étapes de sélection jusqu'à la révélation des sept finalistes.</p>
              <p>La vidéographie et un dispositif de vérification inspiré de la VAR renforcent la transparence des décisions et documentent chaque moment de la compétition.</p>
              <a className="text-link" href="#experience">Explorer l'expérience <ArrowUpRight size={16}/></a>
            </div>
          </div>
          <div className="process-grid">
            <article className="process-card"><span>01 / SELECT</span><Users/><h3>20 TALENTS</h3><p>Une sélection sur candidature pour réunir les danseurs les plus prometteurs.</p></article>
            <article className="process-card"><span>02 / CREATE</span><Video/><h3>UNE CRÉATION</h3><p>Une chorégraphie de cinq minutes, travaillée lors d'au moins dix répétitions.</p></article>
            <article className="process-card"><span>03 / VERIFY</span><ShieldCheck/><h3>ESPRIT VAR</h3><p>La vidéo aide le jury à examiner les situations contestées avec rigueur.</p></article>
            <article className="process-card process-highlight"><span>04 / REVEAL</span><Trophy/><h3>7 FINALISTES</h3><p>Sept places à gagner. Une cagnotte globale prévue de 3 500 000 FC.</p></article>
          </div>
        </section>

        <section className="manifesto">
          <div className="manifesto-bg"/>
          <div className="wrap manifesto-content">
            <span className="section-kicker light">02 — OUR MANIFESTO</span>
            <p>THE FUTURE OF<br/><em>AFRICAN DANCE</em><br/>IS <span>IN MOTION.</span></p>
            <span className="manifesto-caption">Une scène pour les talents. Une expérience pour le public. Une plateforme d'impact pour les marques.</span>
          </div>
        </section>

        <section className="section wrap experience-section" id="experience">
          <div className="section-kicker">03 — BRAND EXPERIENCE</div>
          <div className="section-heading-row">
            <div><h2>DES MARQUES<br/><em>EN MOUVEMENT.</em></h2></div>
            <p>Nous imaginons des collaborations qui dépassent la visibilité : des activations utiles, des expériences mémorables et des indicateurs pour mesurer les retombées.</p>
          </div>
          <div className="brand-feature-grid">
            <article className="brand-feature africell-feature">
              <div className="brand-feature-top"><span>PROPOSITION DE COLLABORATION · 01</span><span className="brand-wordmark">africell<span>.</span></span></div>
              <div className="brand-feature-body">
                <div className="feature-label">CONNECTIVITY / DIGITAL CULTURE</div>
                <h3>AFRICELL<br/><em>DIGITAL EXPERIENCE</em></h3>
                <p>Connecter les talents, la communauté et l'événement grâce à une expérience mobile pensée autour de la culture urbaine.</p>
                <ul>
                  <li><Check/> Campagnes digitales et contenus co-brandés</li>
                  <li><Check/> Connectivité et expérience mobile sur site</li>
                  <li><Check/> Notifications et informations avec consentement</li>
                  <li><Check/> Activations communautaires et jeux-concours</li>
                </ul>
                <a href="#contact" className="feature-link">Imaginer cette collaboration <ArrowUpRight size={16}/></a>
              </div>
              <div className="feature-orb orb-blue"/>
            </article>
            <article className="brand-feature bracongo-feature">
              <div className="brand-feature-top"><span>PROPOSITION DE COLLABORATION · 02</span><span className="brand-wordmark bracongo-word">BRACONGO</span></div>
              <div className="brand-feature-body">
                <div className="feature-label">BRAND ACTIVATION / STREET CULTURE</div>
                <h3>BRACONGO<br/><em>STREET CULTURE EXPERIENCE</em></h3>
                <p>Créer un lien authentique entre la marque, les danseurs et le public au cœur d'une célébration de la culture urbaine.</p>
                <ul>
                  <li><Check/> Présence de marque dans les espaces stratégiques</li>
                  <li><Check/> Activations et expériences sur le lieu de l'événement</li>
                  <li><Check/> Contenus photo et vidéo dédiés</li>
                  <li><Check/> Codes promotionnels et opérations spéciales</li>
                </ul>
                <a href="#contact" className="feature-link">Imaginer cette collaboration <ArrowUpRight size={16}/></a>
              </div>
              <div className="feature-orb orb-gold"/>
            </article>
          </div>
          <p className="partner-note"><span className="note-dot"/> Africell et Bracongo sont des partenaires ciblés. Ces pistes d'activation constituent des propositions soumises à discussion, sans partenariat confirmé à ce stade.</p>
        </section>

        <section className="section impact-section">
          <div className="wrap">
            <div className="section-kicker">04 — MEASURABLE IMPACT</div>
            <div className="section-heading-row">
              <h2>LA VISIBILITÉ<br/><em>SE MESURE.</em></h2>
              <p>Un aperçu du futur espace de suivi partenaire. Les indicateurs ci-dessous sont des exemples de démonstration, pas des résultats réels de campagne.</p>
            </div>
            <div className="dashboard">
              <div className="dashboard-head"><div><span className="dash-live"/> SPONSOR IMPACT OVERVIEW</div><span className="demo-tag">DONNÉES DE DÉMONSTRATION</span></div>
              <div className="metric-grid">
                <div className="metric"><span>VISITES DE LA PLATEFORME</span><strong>—</strong><small>Disponible après lancement</small></div>
                <div className="metric"><span>VUES DES CONTENUS</span><strong>—</strong><small>Suivi des médias publiés</small></div>
                <div className="metric"><span>INTERACTIONS SPONSORS</span><strong>—</strong><small>Engagement mesuré</small></div>
                <div className="metric"><span>CODES ACTIVÉS</span><strong>—</strong><small>Selon activation retenue</small></div>
              </div>
              <div className="dashboard-bottom"><BarChart3/><span>Les données réelles seront collectées et présentées après activation des outils de mesure et validation des campagnes.</span><ArrowUpRight/></div>
            </div>
          </div>
        </section>

        <section className="section organizers-section wrap" id="organizers">
          <div className="section-kicker">05 — THE ORGANIZERS</div>
          <div className="organizers-grid">
            <div><h2>PORTÉ PAR<br/><em>LA PASSION.</em></h2><p>Une initiative qui associe vision entrepreneuriale, expertise culturelle et engagement pour la scène artistique congolaise.</p></div>
            <div className="organizer-card"><span className="organizer-index">INITIATIVE & COORDINATION PRINCIPALE</span><strong>MÀFIKIRI<br/>PROJECT</strong><span className="organizer-rule"/><p>Coordination du projet, développement de la plateforme et relations de partenariat.</p></div>
            <div className="organizer-card organizer-umoja"><span className="organizer-index">ORGANISATION CULTURELLE</span><strong>BALLET<br/>UMOJA</strong><span className="organizer-rule"/><p>Expertise artistique, ancrage culturel et contribution à l'organisation du championnat.</p></div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="wrap contact-grid">
            <div className="contact-copy">
              <div className="section-kicker light">06 — LET'S BUILD TOGETHER</div>
              <h2>VOTRE MARQUE.<br/><em>NOTRE SCÈNE.</em><br/>UN IMPACT.</h2>
              <p>Vous souhaitez explorer une collaboration, recevoir le dossier de présentation ou discuter d'une activation ? Parlons de votre ambition.</p>
              <div className="contact-meta"><Mail/><span>Équipe partenariats<br/><strong>Réponse via les coordonnées communiquées par l'organisation</strong></span></div>
            </div>
            <form className="contact-form" onSubmit={submit}>
              <div className="form-title">INITIER UNE CONVERSATION <ArrowUpRight/></div>
              <label>Nom complet<input required value={form.name} onChange={e => setForm({...form, name:e.target.value})} placeholder="Votre nom"/></label>
              <label>Entreprise / organisation<input required value={form.company} onChange={e => setForm({...form, company:e.target.value})} placeholder="Nom de votre organisation"/></label>
              <label>Adresse e-mail<input required type="email" value={form.email} onChange={e => setForm({...form, email:e.target.value})} placeholder="nom@entreprise.com"/></label>
              <label>Type d'intérêt<select value={form.interest} onChange={e => setForm({...form, interest:e.target.value})}><option>Partenariat stratégique</option><option>Activation de marque</option><option>Partenariat média</option><option>Collaboration culturelle</option><option>Autre demande</option></select></label>
              <label>Votre message<textarea required rows={3} value={form.message} onChange={e => setForm({...form, message:e.target.value})} placeholder="Parlez-nous de votre projet..."/></label>
              <button className="button button-primary form-submit" type="submit">Envoyer une demande <ArrowUpRight/></button>
              {sent && <p className="form-feedback">Votre application e-mail va s'ouvrir avec votre demande préremplie. Configurez l'adresse officielle de partenariat avant publication.</p>}
              <small className="form-legal">Prototype : l'envoi utilise votre application e-mail. Le formulaire devra être relié à un service sécurisé avant la mise en production.</small>
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="wrap footer-main">
          <a className="brand footer-brand" href="#home"><span className="brand-mark">7</span><span className="brand-copy"><strong>SEVEN<span>TO</span>SMOKE</strong><small>AFRICAN URBAN DANCE CHAMPIONSHIP</small></span></a>
          <p>THE TALENT. THE DISCIPLINE.<br/>THE PERFORMANCE.</p>
          <a className="back-top" href="#home">RETOUR EN HAUT <ArrowUpRight/></a>
        </div>
        <div className="wrap footer-bottom"><span>© 2027 SEVEN TO SMOKE · MÀFIKIRI PROJECT & BALLET UMOJA</span><span>CONÇU POUR LA CULTURE URBAINE AFRICAINE.</span></div>
      </footer>
    </div>
  );
}

export default App;
