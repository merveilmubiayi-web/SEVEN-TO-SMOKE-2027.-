# SEVEN TO SMOKE — African Urban Dance Championship

Prototype PWA pour la présentation institutionnelle et commerciale du championnat 2027.

## Stack
- React + TypeScript + Vite
- CSS responsive (mobile-first)
- Lucide React
- Web App Manifest + Service Worker

## Démarrage local
```bash
npm install
npm run dev
```

## Vérification de production
```bash
npm run build
npm run preview
```

## Déploiement Vercel
1. Créer un dépôt GitHub nommé `seven-to-smoke-2027`.
2. Envoyer le contenu de ce projet sur la branche `main`.
3. Dans Vercel, importer le dépôt.
4. Framework preset : Vite.
5. Build command : `npm run build`.
6. Output directory : `dist`.

## État du prototype
- Navigation responsive : incluse.
- Sections championnat / partenaires / organisateurs : incluses.
- Espaces de proposition Africell et Bracongo : inclus.
- Indicateurs sponsor : placeholders clairement non chiffrés.
- Formulaire : ouvre le logiciel e-mail du visiteur. L'adresse `partenariats@seven-to-smoke.com` est un placeholder à remplacer par une adresse officielle.
- PWA : manifest et service worker de base inclus.

## À faire avant mise en production
- Remplacer les visuels temporaires par les photos/vidéos autorisées du projet.
- Confirmer la date officielle du challenge (le document source comporte une divergence entre le 29 avril et le 1er mai 2027).
- Valider les coordonnées officielles de contact.
- Ajouter les logos officiels des organisateurs avec leur autorisation.
- Connecter un backend sécurisé pour les demandes et statistiques.
- Mettre en place une politique de confidentialité et les consentements requis.
- Faire tester l'installation PWA sur Android et iOS.
- Vérifier les droits d'utilisation des marques et visuels partenaires avant publication.
